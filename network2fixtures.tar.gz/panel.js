var allResponses = [];

function responseData(url, method, status, body) {
    this.id = allResponses.length;
    this.url = url;
    this.method = method;
    this.status = status;
    this.body = {
        "httpMethod": method,
        "statusCode": status,
        "uri": url,
        "response": JSON.parse(body)
    };
}

function showHide(e) {
    document.getElementById().style.display = 'block'
}

function focusOnClick(e) {
    var range = document.createRange();
    var selection = window.getSelection();
    range.selectNodeContents(e);

    selection.removeAllRanges();
    selection.addRange(range);
}

function drawAll() {
    var content = '';

    allResponses.forEach(function(fixture) {
        content += '<tr class="fixturemeta">';
        content += '<td>' + fixture.id + '</td>';
        content += '<td>' + fixture.url + '</td>';
        content += '<td>' + fixture.method + '</td>';
        content += '<td>' + fixture.status + '</td>';
        content += '</tr>';
        content += '<tr class="fixturebody" style="display: none;"><td colspan="4"><pre>' + JSON.stringify(fixture.body) + '</pre></td></tr>';
    });

    document.getElementById('content').innerHTML = content;

    rebind();
}

function rebind() {
    // Show hide response body
    $('tr.fixturemeta').click(function () {
        $(this).next(".fixturebody").toggle();
    });

    // Highlight response body on click
    $('table pre').on('click', function(){
        var range = document.createRange();
        var selection = window.getSelection();
        range.selectNodeContents(this);
        
        selection.removeAllRanges();
        selection.addRange(range);
    });
}

chrome.devtools.network.onRequestFinished.addListener(function(data) {
    var id = 0;
    if(data.request.url.match(/ovoenergy.com/)) {
        data.getContent(function (responseContent) {
             allResponses.push(new responseData(data.request.url, data.request.method, data.response.status, responseContent));
             drawAll();
        });
    }
});

$('#clear').click(function () {
    allResponses = [];
    drawAll();
});

document.getElementById('content').innerHTML = 'You haven\'t made any requests you big dummy';